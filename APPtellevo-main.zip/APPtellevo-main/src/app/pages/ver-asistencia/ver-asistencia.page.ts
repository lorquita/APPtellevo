import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ver-asistencia',
  templateUrl: './ver-asistencia.page.html',
  styleUrls: ['./ver-asistencia.page.scss'],
})
export class VerAsistenciaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
