import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ver-horario',
  templateUrl: './ver-horario.page.html',
  styleUrls: ['./ver-horario.page.scss'],
})
export class VerHorarioPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
