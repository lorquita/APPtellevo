export interface VerHorario {
    imagen:string,
    titulo:string,
}
