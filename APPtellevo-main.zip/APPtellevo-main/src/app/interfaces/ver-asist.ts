export interface VerAsist {
}
