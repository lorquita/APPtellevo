export interface RegAsist {
    imagen:string;
}
